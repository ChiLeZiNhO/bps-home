
document.addEventListener('DOMContentLoaded', () => {
  console.log("Portal Brasil PlaysStart carregado com sucesso.");
});
